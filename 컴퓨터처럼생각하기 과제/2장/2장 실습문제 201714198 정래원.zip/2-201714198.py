import turtle
print('201714198정래원')
turtle.pensize(7)

radius = int(input('그리고자 하는 원의 반지름을 입력해주세요. :'))
turtle.color('blue')
turtle.circle(radius)

turtle.done()
