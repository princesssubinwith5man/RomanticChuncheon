print('201714198정래원')
cm = int(input("키를 입력하세요. : "))
print("당신의 신장 :",cm)
kg = (cm-100)*0.9
print("적정 몸무게 :",kg)
bkg = kg*1.2
print("과체중 위험 기준 :",bkg)
skg = kg*0.8
print("저체중 위험 기준 :",skg)
