print('201714198정래원')
n = int(input('현재 감염자 수 입력 : '))
mon = n*1.5
tue = mon *1.5
wed = tue *1.5
thu = wed * 1.5
fri = thu *1.5
sat = fri *1.5
sun = sat * 1.5
print('7일 후 예상 감염자 수는 %.1f명 입니다.' % (sun))
