import math

print('201714198정래원')
x = int(input("첫번째 수 : "))
y = int(input("두번째 수 : "))
print("산술평균 : %.1f, 기하평균 : %.1f" % ((x+y)/2,math.sqrt(x*y)))
