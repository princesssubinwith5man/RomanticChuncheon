print('201714198정래원')
number = int(input('숫자를 입력해주세요 : '))
print('입력한 숫자 : %d' %(number))
print('2진수 : {0:b}'.format(number))
print('8진수 : {0:o}'.format(number))
print('16진수 : {0:x}'.format(number))

